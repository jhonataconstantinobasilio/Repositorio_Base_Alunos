lista = [10,20,30,40,50]
lista.insert(4,60)
lista.insert(1,15)
lista.remove(30)
numero=lista.pop(5)
print(lista)
print(numero)

numeros = []
i=0

# enquanto 
while i <5:
    i=i+1
    numeros.append(i)

print(numeros)
fruteira = ["maçã","banana","laranja"]

fruteira.remove("banana")
print(fruteira)

numeros = [1,2,3,4,5]

numeros.clear()
print(numeros)
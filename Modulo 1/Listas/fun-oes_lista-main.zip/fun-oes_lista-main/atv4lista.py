lista = [5,10,15,20]

del lista[2]
print(lista) 

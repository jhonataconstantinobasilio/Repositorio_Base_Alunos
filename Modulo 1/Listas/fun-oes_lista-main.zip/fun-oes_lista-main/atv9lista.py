letras = ["a","b","d"]

letras.insert(2,"c")
letras.remove("a")
print(letras)
lista = ["python","java","c++"]

linguagem=lista.pop(1)
print(lista)
print(linguagem)
lista = [10,20,30]

lista.insert(2,100)

print(lista[2])

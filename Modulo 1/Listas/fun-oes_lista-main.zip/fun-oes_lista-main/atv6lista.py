lista = [100,200,300,400]

valor=lista.pop(3)


print(lista)
print(valor)